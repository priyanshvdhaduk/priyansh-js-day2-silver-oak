<script>
    function myFunction(){
        a=document.getElementsByTagName("input");
        alert([0].value);
        alert([0].value);
    }
</script>